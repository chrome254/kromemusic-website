const esc = value => String(value || '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const availableLinks = credit => Object.entries(credit.links || {}).filter(([, url]) => url);
const cardClass = index => ['cover-a','cover-b','cover-c'][index % 3];
function renderCredits(credits) {
  const order = ['Siaka', 'Manifest', 'Ya Mwisho', 'Take It Slow'];
  credits.sort((a,b) => (order.indexOf(a.title) + 99) % 99 - (order.indexOf(b.title) + 99) % 99 || b.year - a.year);
  const featured = document.querySelector('#featured-work');
  if (featured) featured.innerHTML = credits.slice(0, 3).map((credit, index) => `<article class="release ${index === 0 ? 'tall' : ''} ${cardClass(index)}"><div class="cover-tag">${esc(credit.year)} · Verified credit</div><div class="release-info"><p>${esc(credit.artist)}</p><h3>${esc(credit.title).replace(' ', '<br>')}</h3><span>${credit.roles.map(esc).join(' · ')}</span></div></article>`).join('');
  const creditsList = document.querySelector('#credits-list');
  if (creditsList) creditsList.innerHTML = credits.map(credit => `<div class="credit-row"><strong>${esc(credit.artist)}<br><small>${esc(credit.title)}</small></strong><span>${esc(credit.project)}</span><span>${esc(credit.year)}</span><span>${credit.roles.map(esc).join(' · ')}</span><a href="${esc((availableLinks(credit)[0] || [,'#'])[1])}" target="_blank" rel="noopener">Listen ↗</a></div>`).join('');
  const musicList = document.querySelector('#music-list');
  if (musicList) musicList.innerHTML = credits.slice(0, 6).map((credit, index) => { const links = availableLinks(credit); return `<article class="music-card ${cardClass(index)}"><div class="cover-tag">${esc(credit.year)} · Verified credit</div><div><p>${esc(credit.artist)}</p><h3>${esc(credit.title)}</h3><span>${credit.roles.map(esc).join(' · ')}</span></div><footer>${links.length ? links.map(([name,url]) => `<a href="${esc(url)}" target="_blank" rel="noopener">${esc(name.replace('appleMusic','Apple Music'))} ↗</a>`).join('') : '<span>Links being added</span>'}</footer></article>`; }).join('');
}
fetch('credits-data.json').then(response => response.ok ? response.json() : Promise.reject()).then(data => renderCredits(data.credits.filter(credit => ['verified','client-confirmed'].includes(credit.status)))).catch(() => { const target = document.querySelector('#credits-list, #music-list'); if (target) target.innerHTML = '<p class="catalogue-error">Credits are temporarily unavailable. Please refresh or return shortly.</p>'; });
document.querySelectorAll('.filter').forEach(group => group.addEventListener('click', event => { const button = event.target.closest('button'); if (!button) return; group.querySelectorAll('button').forEach(item => item.classList.remove('active')); button.classList.add('active'); }));
